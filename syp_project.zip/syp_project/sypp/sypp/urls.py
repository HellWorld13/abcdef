from django.contrib import admin
from django.urls import path
from django.urls import path,include

admin.site.site_header = "Rental Home Admin"
admin.site.site_title = "Rental Home Admin Portal"
admin.site.index_title = "Welcome to Rental Home Researcher Portal"

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('sypa.urls'))
]
